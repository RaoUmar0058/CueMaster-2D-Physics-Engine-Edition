# CueMaster 2D — Play Store Setup

This folder is a ready-to-go Capacitor project. `npm install` has already been run and the
Capacitor packages are in place. The game file is already copied into `www/index.html`.

## What's already done for you
- ✅ `package.json` with Capacitor dependencies installed
- ✅ `capacitor.config.json` configured (app id: `com.codensia.cuemaster`)
- ✅ `www/index.html` — the game, with responsive canvas scaling added for mobile screens
- ✅ `privacy-policy.html` — required by Play Console, needs hosting (see Step 5)

## What you still need to do locally
This sandbox has no Android SDK, so the native Android project itself can't be generated here.
Do this on your own machine, with **Android Studio** installed:

### Step 1 — Copy this whole folder to your computer
Unzip it anywhere, e.g. `~/projects/cuemaster-app`.

### Step 2 — Install dependencies (if needed again)
```bash
cd cuemaster-app
npm install
```

### Step 3 — Add the Android platform
```bash
npx cap add android
npx cap sync
```
This generates the full `android/` folder (Gradle project) inside this directory.

### Step 4 — Open in Android Studio
```bash
npx cap open android
```
Or just open the `android/` folder directly from Android Studio.

Inside Android Studio:
1. Let Gradle sync finish.
2. Add your app icon: right-click `res` → **New → Image Asset** → pick a 512x512 PNG.
3. (Optional) Lock orientation to landscape in
   `android/app/src/main/AndroidManifest.xml` by adding to the `<activity>` tag:
   ```xml
   android:screenOrientation="landscape"
   ```
4. Update version name/code in `android/app/build.gradle` before each release.

### Step 5 — Host the privacy policy
Play Console needs a **public URL**, not a file. Easiest free option:
1. Push `privacy-policy.html` to a public GitHub repo.
2. Enable **GitHub Pages** for that repo (Settings → Pages).
3. Your policy will be live at something like:
   `https://yourusername.github.io/cuemaster-privacy/privacy-policy.html`
4. Before publishing, edit the placeholders in the file:
   - the date at the top
   - your contact email at the bottom

### Step 6 — Generate a signed Android App Bundle (.aab)
In Android Studio: **Build → Generate Signed Bundle / APK → Android App Bundle**
- First time: click **Create new...** to make a keystore.
  **Save this keystore file somewhere safe and back it up.** You need the exact same
  keystore for every future update — losing it means you can never update this app listing again.
- Choose **release** build variant.
- This produces a `.aab` file, which is what Play Console wants (not `.apk`).

### Step 7 — Google Play Console
1. Go to https://play.google.com/console, pay the one-time $25 registration fee.
2. Create a new app: name, default language, category (Casual / Arcade fits well).
3. Fill in the **Store listing**:
   - Short description (max 80 characters)
   - Full description (max 4000 characters)
   - Feature graphic: 1024x500 PNG
   - At least 2 phone screenshots
   - Paste your hosted privacy policy URL from Step 5
4. Complete the **Content rating questionnaire** (this game should land as "Everyone").
5. Complete the **Data safety** section — since the app collects nothing, answer accordingly.
6. Upload the `.aab` under **Production** (or better: **Internal testing** first).

### Step 8 — Test before going live
Strongly recommended order:
1. **Internal testing** track — just you.
2. **Closed testing** — invite a few friends, collect feedback.
3. **Production** — once you're happy with stability and feedback.

## Notes on the current game build
- Coins/score are stored in memory only (reset when the app is fully closed). If you want
  real persistent save data using `localStorage` (works fine in a real installed app, unlike
  in Claude's in-chat preview), just ask — it's a small addition to `www/index.html`.
- Canvas now scales responsively to fit different phone screens, but test on a couple of
  real screen sizes/aspect ratios before submitting.
